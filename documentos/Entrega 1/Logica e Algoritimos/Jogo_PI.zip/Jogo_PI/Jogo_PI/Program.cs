﻿class Program
{
    static void Main(string[] args)
    {
        int energia = 100;
        int fase = 0;
        int pontos = 0;
        bool estaVivo = true;
        string SN = "S";

        Console.Clear();
        Console.WriteLine("╔════════════════════════════════════╗");
        Console.WriteLine("║      FUGA DO LABORATÓRIO           ║");
        Console.WriteLine("╚════════════════════════════════════╝");

        Console.WriteLine("\nVocê está preso no lab da FECAP!");
        Console.WriteLine("Responda os desafios para escapar.\n");
        Console.Write("Pressione ENTER para começar...");
        Console.ReadLine();

        while (estaVivo && SN == "S")
        {
            Console.WriteLine("==================================================");
            Console.WriteLine("                    TERMINAL");
            Console.WriteLine("==================================================");

            Console.WriteLine("Energia: " + energia + "   *  Pontos: " + pontos + "     Fase: " + fase);
            Console.WriteLine("--------------------------------------------------");

            if (fase == 0)
            {
                Console.WriteLine("Próximo número: 2, 4, 8, 16, ___ ?");
                string resp = Console.ReadLine();

                if (resp == "32")
                {
                    pontos += 25;
                    Console.WriteLine("\nVocê ganhou +25 pontos!");
                    Console.WriteLine("Pontos totais: " + pontos);
                    Console.WriteLine("Parabéns! Passou de fase!\n");
                    fase = 1;
                }
                else
                {
                    energia -= 25;
                    Console.WriteLine("Voce errou!");
                    Console.WriteLine("Energia restante: " + energia);

                    if (energia <= 0)
                    {
                        estaVivo = false;
                    }
                    else
                    {
                        Console.WriteLine("Deseja Continuar? (S ou N)");
                        SN = Console.ReadLine().ToUpper();
                    }
                }
            }

            else if (fase == 1)
            {
                Console.WriteLine("\nQual o tipo que armazena texto?");
                string resp2 = Console.ReadLine();

                if (resp2.ToLower() == "string")
                {
                    pontos += 25;
                    Console.WriteLine("\nVocê ganhou +25 pontos!");
                    Console.WriteLine("Pontos totais: " + pontos);
                    Console.WriteLine("Parabéns! Passou de fase!\n");
                    fase = 2;
                }
                else
                {
                    energia -= 25;
                    Console.WriteLine("Voce errou!");
                    Console.WriteLine("Energia restante: " + energia);

                    if (energia <= 0)
                    {
                        estaVivo = false;
                    }
                    else
                    {
                        Console.WriteLine("Deseja Continuar? (S ou N)");
                        SN = Console.ReadLine().ToUpper();
                    }
                }
            }
            else if (fase == 2)
            {
                Console.WriteLine("\nOperador resto da divisão? \n A) / \n B) // \n C) % \n D) mod");
                string resp = Console.ReadLine();

                if (resp.ToUpper() == "C")
                {
                    pontos += 25;
                    Console.WriteLine("\nVocê ganhou +25 pontos!");
                    Console.WriteLine("Pontos totais: " + pontos);
                    Console.WriteLine("Parabéns! Passou de fase!\n");
                    fase = 3;
                }
                else
                {
                    energia -= 25;
                    Console.WriteLine("Voce errou!");
                    Console.WriteLine("Energia restante: " + energia);

                    if (energia <= 0)
                    {
                        estaVivo = false;
                    }
                    else
                    {
                        Console.WriteLine("Deseja Continuar? (S ou N)");
                        SN = Console.ReadLine().ToUpper();
                    }
                }
            }
            else if (fase == 3)
            {
                Console.WriteLine("\nQuantas vezes roda while(i < 5) com i=0?");
                string resp = Console.ReadLine();

                if (resp == "5")
                {
                    pontos += 25;
                    Console.WriteLine("\nVocê ganhou +25 pontos!");
                    Console.WriteLine("Pontos totais: " + pontos);
                    Console.WriteLine("Parabéns! Passou de fase!\n");
                    fase = 4;
                }
                else
                {
                    energia -= 25;
                    Console.WriteLine("Voce errou!");
                    Console.WriteLine("Energia restante: " + energia);

                    if (energia <= 0)
                    {
                        estaVivo = false;
                    }
                    else
                    {
                        Console.WriteLine("Deseja Continuar? (S ou N)");
                        SN = Console.ReadLine().ToUpper();
                    }
                }
            }

            if (fase == 4)
            {
                Console.WriteLine("==================================================");
                Console.WriteLine("          VOCÊ SE LIBERTOU!");
                Console.WriteLine("==================================================");
                Console.WriteLine("Total de Pontos: " + pontos);
                Console.WriteLine("==================================================");
                break;
            }

            Console.WriteLine();
        }
        Console.WriteLine("\n==================================================");
        Console.WriteLine("                 RELATÓRIO FINAL");
        Console.WriteLine("==================================================");
        Console.WriteLine("Energia restante : " + energia);
        Console.WriteLine("Pontos conquistados: " + pontos);
        Console.WriteLine("Fase alcançada    : " + fase);

        if (!estaVivo)
        {
            Console.WriteLine("\nVocê Perdeu! Energia esgotada...");
        }
        else if (SN == "N")
        {
            Console.WriteLine("\nVocê desistiu! Aguardando Zelador...");
        }
        else
        {
            Console.WriteLine("\nParabéns! Você completou o jogo com sucesso!");
        }

        Console.WriteLine("==================================================");
    }
}